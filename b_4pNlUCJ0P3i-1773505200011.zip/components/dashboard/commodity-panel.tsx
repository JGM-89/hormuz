'use client';

import { useState } from 'react';
import { ChevronDown, ChevronUp, TrendingUp, TrendingDown, AlertTriangle } from 'lucide-react';
import { ScrollArea } from '@/components/ui/scroll-area';
import { commodities, hormuzRiskPremium, type Commodity } from '@/lib/mock-data';
import { cn } from '@/lib/utils';

function MiniSparkline({ data, color }: { data: number[]; color: string }) {
  const min = Math.min(...data);
  const max = Math.max(...data);
  const range = max - min || 1;
  const width = 60;
  const height = 20;
  
  const points = data.map((value, i) => {
    const x = (i / (data.length - 1)) * width;
    const y = height - ((value - min) / range) * height;
    return `${x},${y}`;
  }).join(' ');
  
  return (
    <svg width={width} height={height} className="flex-shrink-0">
      <polyline
        points={points}
        fill="none"
        stroke={color}
        strokeWidth="1.5"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
    </svg>
  );
}

function DayRangeBar({ min, max, current }: { min: number; max: number; current: number }) {
  const range = max - min;
  const position = ((current - min) / range) * 100;
  
  return (
    <div className="relative h-2 w-full rounded-full bg-surface-3">
      <div
        className="absolute top-1/2 h-3 w-1 -translate-y-1/2 rounded-full bg-primary"
        style={{ left: `${position}%` }}
      />
    </div>
  );
}

function SensitivityBar({ value }: { value: number }) {
  const getColor = (v: number) => {
    if (v >= 75) return '#ff1744';
    if (v >= 50) return '#ffab00';
    if (v >= 25) return '#00b4d8';
    return '#00e676';
  };
  
  return (
    <div className="flex items-center gap-2">
      <div className="relative h-2 flex-1 rounded-full bg-surface-3">
        <div
          className="h-full rounded-full transition-all"
          style={{ width: `${value}%`, backgroundColor: getColor(value) }}
        />
      </div>
      <span className="font-mono text-xs" style={{ color: getColor(value) }}>
        {value}%
      </span>
    </div>
  );
}

function CommodityRow({ commodity }: { commodity: Commodity }) {
  const [expanded, setExpanded] = useState(false);
  const isPositive = commodity.change >= 0;
  const changeColor = isPositive ? '#00e676' : '#ff1744';
  
  return (
    <div className="border-b border-border/50">
      <button
        onClick={() => setExpanded(!expanded)}
        className="flex w-full items-center gap-3 p-3 text-left transition-colors hover:bg-surface-3"
      >
        <div className="min-w-0 flex-1">
          <div className="flex items-center gap-2">
            <span className="font-mono text-xs font-semibold text-muted-foreground">
              {commodity.symbol}
            </span>
            <span className="truncate text-sm text-foreground">{commodity.name}</span>
          </div>
        </div>
        
        <MiniSparkline data={commodity.sparklineData} color={changeColor} />
        
        <div className="text-right">
          <div className="font-mono text-sm font-semibold text-foreground">
            {commodity.price.toLocaleString(undefined, {
              minimumFractionDigits: 2,
              maximumFractionDigits: 2,
            })}
          </div>
          <div className="flex items-center justify-end gap-1" style={{ color: changeColor }}>
            {isPositive ? (
              <TrendingUp className="h-3 w-3" />
            ) : (
              <TrendingDown className="h-3 w-3" />
            )}
            <span className="font-mono text-xs">
              {isPositive ? '+' : ''}{commodity.changePercent.toFixed(2)}%
            </span>
          </div>
        </div>
        
        <ChevronDown
          className={cn(
            'h-4 w-4 text-muted-foreground transition-transform',
            expanded && 'rotate-180'
          )}
        />
      </button>
      
      {expanded && (
        <div className="space-y-3 bg-surface-3/50 p-3">
          {/* OHLC Grid */}
          <div>
            <div className="mb-2 text-[10px] font-semibold uppercase tracking-wider text-muted-foreground">
              OHLC
            </div>
            <div className="grid grid-cols-4 gap-2">
              {(['open', 'high', 'low', 'close'] as const).map((key) => (
                <div key={key} className="rounded bg-surface-2 p-2 text-center">
                  <div className="text-[9px] uppercase text-muted-foreground">{key[0]}</div>
                  <div className="font-mono text-xs text-foreground">
                    {commodity.ohlc[key].toFixed(2)}
                  </div>
                </div>
              ))}
            </div>
          </div>
          
          {/* Day Range */}
          <div>
            <div className="mb-2 text-[10px] font-semibold uppercase tracking-wider text-muted-foreground">
              Day Range
            </div>
            <div className="flex items-center gap-2">
              <span className="font-mono text-xs text-muted-foreground">
                {commodity.dayRange.min.toFixed(2)}
              </span>
              <div className="flex-1">
                <DayRangeBar
                  min={commodity.dayRange.min}
                  max={commodity.dayRange.max}
                  current={commodity.price}
                />
              </div>
              <span className="font-mono text-xs text-muted-foreground">
                {commodity.dayRange.max.toFixed(2)}
              </span>
            </div>
          </div>
          
          {/* Hormuz Sensitivity */}
          <div>
            <div className="mb-2 flex items-center gap-1.5 text-[10px] font-semibold uppercase tracking-wider text-muted-foreground">
              <AlertTriangle className="h-3 w-3" />
              Hormuz Sensitivity
            </div>
            <SensitivityBar value={commodity.hormuzSensitivity} />
          </div>
        </div>
      )}
    </div>
  );
}

export function CommodityPanel() {
  return (
    <div className="flex h-full flex-col">
      <div className="border-b border-border p-4">
        <h2 className="text-xs font-semibold uppercase tracking-wider text-muted-foreground">
          COMMODITY PRICES
        </h2>
      </div>
      
      <ScrollArea className="flex-1">
        <div>
          {commodities.map((commodity) => (
            <CommodityRow key={commodity.id} commodity={commodity} />
          ))}
        </div>
      </ScrollArea>
      
      {/* Hormuz Risk Premium Card */}
      <div className="border-t border-border bg-surface-2 p-4">
        <div className="mb-3 flex items-center gap-2">
          <div className="h-2 w-2 rounded-full bg-[#ff1744] led-red" />
          <h3 className="text-[10px] font-semibold uppercase tracking-wider text-[#ff1744]">
            Hormuz Risk Premium
          </h3>
        </div>
        
        <div className="grid grid-cols-2 gap-3">
          <div className="rounded bg-surface-3 p-3">
            <div className="text-[10px] uppercase text-muted-foreground">Current</div>
            <div className="flex items-baseline gap-1">
              <span className="font-mono text-xl font-bold text-foreground">
                ${hormuzRiskPremium.currentPremium.toFixed(2)}
              </span>
              <span className="text-xs text-muted-foreground">/bbl</span>
            </div>
            <div className="flex items-center gap-1 text-xs text-[#ff1744]">
              {hormuzRiskPremium.trend === 'up' ? (
                <ChevronUp className="h-3 w-3" />
              ) : (
                <ChevronDown className="h-3 w-3" />
              )}
              <span>{hormuzRiskPremium.percentOfBrent.toFixed(1)}% of Brent</span>
            </div>
          </div>
          
          <div className="rounded bg-surface-3 p-3">
            <div className="text-[10px] uppercase text-muted-foreground">30-Day Avg</div>
            <div className="flex items-baseline gap-1">
              <span className="font-mono text-xl font-bold text-foreground">
                ${hormuzRiskPremium.thirtyDayAvg.toFixed(2)}
              </span>
              <span className="text-xs text-muted-foreground">/bbl</span>
            </div>
            <div className="text-xs text-muted-foreground">
              {((hormuzRiskPremium.currentPremium - hormuzRiskPremium.thirtyDayAvg) /
                hormuzRiskPremium.thirtyDayAvg *
                100
              ).toFixed(1)}% vs avg
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
