'use client';

import { Newspaper } from 'lucide-react';
import { newsItems } from '@/lib/mock-data';

export function NewsTicker() {
  // Duplicate items for seamless loop
  const duplicatedItems = [...newsItems, ...newsItems];
  
  return (
    <div className="flex h-10 items-center overflow-hidden border-t border-border bg-surface-2">
      <div className="flex h-full items-center gap-2 border-r border-border bg-surface-3 px-4">
        <Newspaper className="h-4 w-4 text-primary" />
        <span className="text-[10px] font-semibold uppercase tracking-wider text-muted-foreground">
          Live Feed
        </span>
      </div>
      
      <div className="relative flex-1 overflow-hidden">
        <div className="ticker-scroll flex items-center whitespace-nowrap py-2">
          {duplicatedItems.map((item, index) => (
            <div key={`${item.id}-${index}`} className="flex items-center px-6">
              <span className="mr-2 text-xs font-semibold text-primary">
                {item.source}:
              </span>
              <span className="text-xs text-foreground">{item.headline}</span>
              <span className="mx-6 text-muted-foreground">•</span>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
