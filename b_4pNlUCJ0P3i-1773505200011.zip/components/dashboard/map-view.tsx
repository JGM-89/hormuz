'use client';

import { useEffect, useRef, useState, useCallback } from 'react';
import maplibregl from 'maplibre-gl';
import 'maplibre-gl/dist/maplibre-gl.css';
import { vessels, chokepointLocations, type Vessel } from '@/lib/mock-data';
import { X, Ship, Anchor, Navigation } from 'lucide-react';

interface MapViewProps {
  selectedVessel: Vessel | null;
  onSelectVessel: (vessel: Vessel | null) => void;
}

const vesselTypeColors = {
  tanker: '#00b4d8',
  cargo: '#ffab00',
  other: '#94a3b8',
};

export function MapView({ selectedVessel, onSelectVessel }: MapViewProps) {
  const mapContainer = useRef<HTMLDivElement>(null);
  const map = useRef<maplibregl.Map | null>(null);
  const markersRef = useRef<maplibregl.Marker[]>([]);
  const [popupVessel, setPopupVessel] = useState<Vessel | null>(null);
  const [styleLoaded, setStyleLoaded] = useState(false);

  const createVesselMarker = useCallback((vessel: Vessel, isSelected: boolean) => {
    const color = vesselTypeColors[vessel.type];
    const size = isSelected ? 24 : 16;
    
    const el = document.createElement('div');
    el.className = 'vessel-marker';
    el.style.cssText = `
      width: ${size}px;
      height: ${size}px;
      cursor: pointer;
      transform: rotate(${vessel.heading}deg);
      transition: all 0.2s ease;
    `;
    
    el.innerHTML = `
      <svg viewBox="0 0 24 24" width="${size}" height="${size}">
        <path 
          d="M12 2L4 20h16L12 2z" 
          fill="${color}" 
          stroke="${isSelected ? '#fff' : color}"
          stroke-width="2"
          filter="${isSelected ? 'drop-shadow(0 0 8px ' + color + ')' : ''}"
        />
      </svg>
    `;
    
    return el;
  }, []);

  // Initialize map
  useEffect(() => {
    if (!mapContainer.current || map.current) return;

    map.current = new maplibregl.Map({
      container: mapContainer.current,
      style: {
        version: 8,
        sources: {
          'carto-dark': {
            type: 'raster',
            tiles: [
              'https://a.basemaps.cartocdn.com/dark_all/{z}/{x}/{y}@2x.png',
              'https://b.basemaps.cartocdn.com/dark_all/{z}/{x}/{y}@2x.png',
              'https://c.basemaps.cartocdn.com/dark_all/{z}/{x}/{y}@2x.png',
            ],
            tileSize: 256,
            attribution: '© CARTO, © OpenStreetMap contributors',
          },
        },
        layers: [
          {
            id: 'carto-dark-layer',
            type: 'raster',
            source: 'carto-dark',
            minzoom: 0,
            maxzoom: 19,
          },
        ],
      },
      center: [56.25, 26.5],
      zoom: 7,
      minZoom: 5,
      maxZoom: 12,
    });

    map.current.addControl(new maplibregl.NavigationControl(), 'top-left');

    map.current.on('load', () => {
      setStyleLoaded(true);
    });

    // Add chokepoint markers
    chokepointLocations.forEach((location) => {
      const el = document.createElement('div');
      el.className = 'chokepoint-marker';
      el.innerHTML = `
        <div style="
          background: rgba(0, 180, 216, 0.2);
          border: 2px solid #00b4d8;
          border-radius: 50%;
          width: 32px;
          height: 32px;
          display: flex;
          align-items: center;
          justify-content: center;
          box-shadow: 0 0 16px rgba(0, 180, 216, 0.4);
        ">
          <div style="
            background: #00b4d8;
            width: 8px;
            height: 8px;
            border-radius: 50%;
          "></div>
        </div>
        <div style="
          position: absolute;
          top: 36px;
          left: 50%;
          transform: translateX(-50%);
          white-space: nowrap;
          font-size: 10px;
          font-weight: 600;
          color: #00b4d8;
          text-transform: uppercase;
          letter-spacing: 0.5px;
          text-shadow: 0 0 8px rgba(0, 180, 216, 0.8);
        ">${location.name}</div>
      `;
      
      new maplibregl.Marker({ element: el })
        .setLngLat([location.lng, location.lat])
        .addTo(map.current!);
    });

    return () => {
      map.current?.remove();
      map.current = null;
    };
  }, []);

  // Update vessel markers
  useEffect(() => {
    if (!map.current || !styleLoaded) return;

    // Clear existing markers
    markersRef.current.forEach((marker) => marker.remove());
    markersRef.current = [];

    // Add vessel markers
    vessels.forEach((vessel) => {
      const isSelected = selectedVessel?.id === vessel.id;
      const el = createVesselMarker(vessel, isSelected);
      
      el.addEventListener('click', () => {
        setPopupVessel(vessel);
        onSelectVessel(vessel);
      });

      // Add trail line
      if (vessel.trail.length > 1 && map.current) {
        const sourceId = `trail-${vessel.id}`;
        const layerId = `trail-layer-${vessel.id}`;
        
        // Remove existing source and layer
        if (map.current.getLayer(layerId)) {
          map.current.removeLayer(layerId);
        }
        if (map.current.getSource(sourceId)) {
          map.current.removeSource(sourceId);
        }

        map.current.addSource(sourceId, {
          type: 'geojson',
          data: {
            type: 'Feature',
            properties: {},
            geometry: {
              type: 'LineString',
              coordinates: vessel.trail,
            },
          },
        });

        map.current.addLayer({
          id: layerId,
          type: 'line',
          source: sourceId,
          layout: {
            'line-join': 'round',
            'line-cap': 'round',
          },
          paint: {
            'line-color': vesselTypeColors[vessel.type],
            'line-width': isSelected ? 3 : 2,
            'line-opacity': isSelected ? 0.8 : 0.4,
            'line-dasharray': [2, 2],
          },
        });
      }

      const marker = new maplibregl.Marker({ element: el })
        .setLngLat([vessel.lng, vessel.lat])
        .addTo(map.current!);

      markersRef.current.push(marker);
    });
  }, [selectedVessel, createVesselMarker, onSelectVessel, styleLoaded]);

  // Fly to selected vessel
  useEffect(() => {
    if (selectedVessel && map.current) {
      map.current.flyTo({
        center: [selectedVessel.lng, selectedVessel.lat],
        zoom: 9,
        duration: 1000,
      });
      setPopupVessel(selectedVessel);
    }
  }, [selectedVessel]);

  return (
    <div className="relative h-full w-full crt-vignette scanlines">
      <div ref={mapContainer} className="h-full w-full" />
      
      {/* Live indicator */}
      <div className="absolute left-4 top-4 z-10 flex items-center gap-2 rounded bg-surface-2/90 px-3 py-1.5 backdrop-blur-sm">
        <div className="h-2 w-2 animate-pulse rounded-full bg-[#00e676] led-green" />
        <span className="font-mono text-xs font-semibold uppercase tracking-wider text-[#00e676]">
          Live
        </span>
      </div>

      {/* Legend */}
      <div className="absolute bottom-4 left-4 z-10 rounded bg-surface-2/90 p-3 backdrop-blur-sm">
        <div className="mb-2 text-[10px] font-semibold uppercase tracking-wider text-muted-foreground">
          Vessel Types
        </div>
        <div className="space-y-1.5">
          {Object.entries(vesselTypeColors).map(([type, color]) => (
            <div key={type} className="flex items-center gap-2">
              <svg viewBox="0 0 24 24" width="12" height="12">
                <path d="M12 2L4 20h16L12 2z" fill={color} />
              </svg>
              <span className="text-xs capitalize text-foreground">{type}</span>
            </div>
          ))}
        </div>
      </div>

      {/* Vessel Popup */}
      {popupVessel && (
        <div className="absolute right-4 top-4 z-10 w-72 rounded-lg border border-border bg-surface-2/95 p-4 backdrop-blur-sm">
          <button
            onClick={() => {
              setPopupVessel(null);
              onSelectVessel(null);
            }}
            className="absolute right-2 top-2 rounded p-1 hover:bg-surface-3"
          >
            <X className="h-4 w-4 text-muted-foreground" />
          </button>
          
          <div className="mb-3 flex items-center gap-2">
            <span className="text-xl">{popupVessel.flagEmoji}</span>
            <div>
              <h3 className="font-mono text-sm font-bold text-foreground">
                {popupVessel.name}
              </h3>
              <p className="text-xs text-muted-foreground">{popupVessel.flag}</p>
            </div>
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div className="rounded bg-surface-3 p-2">
              <div className="mb-1 text-[10px] uppercase tracking-wider text-muted-foreground">
                Status
              </div>
              <div className="flex items-center gap-1.5">
                {popupVessel.status === 'transit' ? (
                  <>
                    <Ship className="h-3.5 w-3.5 text-[#00e676]" />
                    <span className="font-mono text-sm text-[#00e676]">In Transit</span>
                  </>
                ) : (
                  <>
                    <Anchor className="h-3.5 w-3.5 text-[#ffab00]" />
                    <span className="font-mono text-sm text-[#ffab00]">Anchored</span>
                  </>
                )}
              </div>
            </div>
            
            <div className="rounded bg-surface-3 p-2">
              <div className="mb-1 text-[10px] uppercase tracking-wider text-muted-foreground">
                Speed
              </div>
              <div className="font-mono text-sm text-foreground">
                {popupVessel.speed} kn
              </div>
            </div>
            
            <div className="rounded bg-surface-3 p-2">
              <div className="mb-1 text-[10px] uppercase tracking-wider text-muted-foreground">
                Heading
              </div>
              <div className="flex items-center gap-1.5">
                <Navigation
                  className="h-3.5 w-3.5 text-primary"
                  style={{ transform: `rotate(${popupVessel.heading}deg)` }}
                />
                <span className="font-mono text-sm text-foreground">{popupVessel.heading}°</span>
              </div>
            </div>
            
            <div className="rounded bg-surface-3 p-2">
              <div className="mb-1 text-[10px] uppercase tracking-wider text-muted-foreground">
                Type
              </div>
              <div
                className="inline-block rounded px-1.5 py-0.5 text-xs font-semibold capitalize"
                style={{
                  backgroundColor: vesselTypeColors[popupVessel.type],
                  color: '#030a18',
                }}
              >
                {popupVessel.type}
              </div>
            </div>
          </div>

          {popupVessel.cargo && (
            <div className="mt-3 rounded bg-surface-3 p-2">
              <div className="mb-1 text-[10px] uppercase tracking-wider text-muted-foreground">
                Cargo
              </div>
              <div className="text-sm text-foreground">{popupVessel.cargo}</div>
            </div>
          )}

          <div className="mt-3 rounded bg-surface-3 p-2">
            <div className="mb-1 text-[10px] uppercase tracking-wider text-muted-foreground">
              Destination
            </div>
            <div className="text-sm text-foreground">{popupVessel.destination}</div>
          </div>

          {popupVessel.dwt && (
            <div className="mt-3 rounded bg-surface-3 p-2">
              <div className="mb-1 text-[10px] uppercase tracking-wider text-muted-foreground">
                DWT
              </div>
              <div className="font-mono text-sm text-foreground">
                {popupVessel.dwt.toLocaleString()} t
              </div>
            </div>
          )}
        </div>
      )}
    </div>
  );
}
