'use client';

import { useState, useMemo } from 'react';
import { Search, Ship, Anchor, Filter } from 'lucide-react';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { ScrollArea } from '@/components/ui/scroll-area';
import { vessels, type Vessel, type VesselType } from '@/lib/mock-data';
import { cn } from '@/lib/utils';

interface VesselListProps {
  selectedVesselId: string | null;
  onSelectVessel: (vessel: Vessel) => void;
}

const vesselTypeColors: Record<VesselType, string> = {
  tanker: 'bg-[#00b4d8] text-[#030a18]',
  cargo: 'bg-[#ffab00] text-[#030a18]',
  other: 'bg-[#94a3b8] text-[#030a18]',
};

const vesselTypeBorderColors: Record<VesselType, string> = {
  tanker: 'border-l-[#00b4d8]',
  cargo: 'border-l-[#ffab00]',
  other: 'border-l-[#94a3b8]',
};

export function VesselList({ selectedVesselId, onSelectVessel }: VesselListProps) {
  const [searchQuery, setSearchQuery] = useState('');
  const [typeFilter, setTypeFilter] = useState<VesselType | 'all'>('all');

  const filteredVessels = useMemo(() => {
    return vessels.filter((vessel) => {
      const matchesSearch =
        vessel.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
        vessel.flag.toLowerCase().includes(searchQuery.toLowerCase());
      const matchesType = typeFilter === 'all' || vessel.type === typeFilter;
      return matchesSearch && matchesType;
    });
  }, [searchQuery, typeFilter]);

  const stats = useMemo(() => {
    const total = vessels.length;
    const inTransit = vessels.filter((v) => v.status === 'transit').length;
    const anchored = vessels.filter((v) => v.status === 'anchored').length;
    const avgSpeed =
      vessels.filter((v) => v.status === 'transit').reduce((sum, v) => sum + v.speed, 0) /
      inTransit;
    return { total, inTransit, anchored, avgSpeed: avgSpeed.toFixed(1) };
  }, []);

  return (
    <div className="flex h-full flex-col">
      {/* Header */}
      <div className="border-b border-border p-4">
        <h2 className="mb-4 text-xs font-semibold uppercase tracking-wider text-muted-foreground">
          VESSEL TRACKING
        </h2>

        {/* Search */}
        <div className="relative mb-3">
          <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
          <Input
            placeholder="Search vessels..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="bg-surface-2 pl-9 font-mono text-sm"
          />
        </div>

        {/* Filters */}
        <div className="flex gap-2">
          <button
            onClick={() => setTypeFilter('all')}
            className={cn(
              'flex items-center gap-1.5 rounded px-2 py-1 text-xs font-medium transition-colors',
              typeFilter === 'all'
                ? 'bg-primary text-primary-foreground'
                : 'bg-surface-3 text-muted-foreground hover:text-foreground'
            )}
          >
            <Filter className="h-3 w-3" />
            All
          </button>
          {(['tanker', 'cargo', 'other'] as VesselType[]).map((type) => (
            <button
              key={type}
              onClick={() => setTypeFilter(type)}
              className={cn(
                'rounded px-2 py-1 text-xs font-medium capitalize transition-colors',
                typeFilter === type
                  ? vesselTypeColors[type]
                  : 'bg-surface-3 text-muted-foreground hover:text-foreground'
              )}
            >
              {type}
            </button>
          ))}
        </div>
      </div>

      {/* Stats Bar */}
      <div className="grid grid-cols-4 gap-1 border-b border-border bg-surface-2 p-2">
        <div className="text-center">
          <div className="font-mono text-lg font-bold text-foreground">{stats.total}</div>
          <div className="text-[10px] uppercase tracking-wider text-muted-foreground">Total</div>
        </div>
        <div className="text-center">
          <div className="font-mono text-lg font-bold text-[#00e676]">{stats.inTransit}</div>
          <div className="text-[10px] uppercase tracking-wider text-muted-foreground">Transit</div>
        </div>
        <div className="text-center">
          <div className="font-mono text-lg font-bold text-[#ffab00]">{stats.anchored}</div>
          <div className="text-[10px] uppercase tracking-wider text-muted-foreground">Anchored</div>
        </div>
        <div className="text-center">
          <div className="font-mono text-lg font-bold text-foreground">{stats.avgSpeed}</div>
          <div className="text-[10px] uppercase tracking-wider text-muted-foreground">Avg kn</div>
        </div>
      </div>

      {/* Vessel List */}
      <ScrollArea className="flex-1">
        <div className="p-2">
          {filteredVessels.map((vessel) => (
            <button
              key={vessel.id}
              onClick={() => onSelectVessel(vessel)}
              className={cn(
                'mb-2 w-full rounded border-l-4 bg-surface-2 p-3 text-left transition-all hover:bg-surface-3',
                vesselTypeBorderColors[vessel.type],
                selectedVesselId === vessel.id && 'ring-1 ring-primary'
              )}
            >
              <div className="mb-2 flex items-start justify-between">
                <div className="flex items-center gap-2">
                  <span className="text-base">{vessel.flagEmoji}</span>
                  <span className="font-mono text-sm font-semibold text-foreground">
                    {vessel.name}
                  </span>
                </div>
                <Badge
                  variant="outline"
                  className={cn('text-[10px] uppercase', vesselTypeColors[vessel.type])}
                >
                  {vessel.type}
                </Badge>
              </div>

              <div className="flex items-center justify-between text-xs">
                <div className="flex items-center gap-3">
                  {vessel.status === 'transit' ? (
                    <span className="flex items-center gap-1 text-[#00e676]">
                      <Ship className="h-3 w-3" />
                      <span className="font-mono">{vessel.speed} kn</span>
                    </span>
                  ) : (
                    <span className="flex items-center gap-1 text-[#ffab00]">
                      <Anchor className="h-3 w-3" />
                      <span>Anchored</span>
                    </span>
                  )}
                  <span className="text-muted-foreground">→ {vessel.destination}</span>
                </div>
                <span
                  className="font-mono text-muted-foreground"
                  style={{
                    transform: `rotate(${vessel.heading}deg)`,
                    display: 'inline-block',
                  }}
                >
                  ▲
                </span>
              </div>
            </button>
          ))}
        </div>
      </ScrollArea>
    </div>
  );
}
