'use client';

import { Wind, Waves, Thermometer, Eye, Navigation } from 'lucide-react';
import { weatherData } from '@/lib/mock-data';
import { cn } from '@/lib/utils';

const riskColors = {
  LOW: { bg: 'bg-[#00e676]', text: 'text-[#00e676]', led: 'led-green' },
  MODERATE: { bg: 'bg-[#ffab00]', text: 'text-[#ffab00]', led: 'led-amber' },
  HIGH: { bg: 'bg-[#ff1744]', text: 'text-[#ff1744]', led: 'led-red' },
  SEVERE: { bg: 'bg-[#ff1744]', text: 'text-[#ff1744]', led: 'led-red' },
};

export function WeatherPanel() {
  const risk = riskColors[weatherData.passageRisk];
  
  return (
    <div className="border-b border-border p-4">
      <h2 className="mb-4 text-xs font-semibold uppercase tracking-wider text-muted-foreground">
        WEATHER & PASSAGE RISK
      </h2>
      
      {/* Current Conditions */}
      <div className="mb-4 grid grid-cols-2 gap-3">
        {/* Wind */}
        <div className="rounded bg-surface-3 p-3">
          <div className="mb-2 flex items-center gap-1.5 text-[10px] uppercase text-muted-foreground">
            <Wind className="h-3 w-3" />
            Wind
          </div>
          <div className="flex items-center gap-2">
            <Navigation
              className="h-5 w-5 text-primary"
              style={{ transform: `rotate(${weatherData.windDirection}deg)` }}
            />
            <div>
              <div className="font-mono text-lg font-bold text-foreground">
                {weatherData.windSpeed} kn
              </div>
              <div className="text-xs text-muted-foreground">
                Gusts {weatherData.windGusts} kn
              </div>
            </div>
          </div>
        </div>
        
        {/* Beaufort Scale */}
        <div className="rounded bg-surface-3 p-3">
          <div className="mb-2 text-[10px] uppercase text-muted-foreground">Beaufort</div>
          <div className="flex items-baseline gap-2">
            <span className="font-mono text-2xl font-bold text-primary">
              BF{weatherData.beaufortScale}
            </span>
          </div>
          <div className="truncate text-xs text-muted-foreground">
            {weatherData.beaufortLabel}
          </div>
        </div>
        
        {/* Wave Height */}
        <div className="rounded bg-surface-3 p-3">
          <div className="mb-2 flex items-center gap-1.5 text-[10px] uppercase text-muted-foreground">
            <Waves className="h-3 w-3" />
            Waves
          </div>
          <div className="font-mono text-lg font-bold text-foreground">
            {weatherData.waveHeight} m
          </div>
        </div>
        
        {/* Temperature */}
        <div className="rounded bg-surface-3 p-3">
          <div className="mb-2 flex items-center gap-1.5 text-[10px] uppercase text-muted-foreground">
            <Thermometer className="h-3 w-3" />
            Temp
          </div>
          <div className="font-mono text-lg font-bold text-foreground">
            {weatherData.temperature}°C
          </div>
        </div>
        
        {/* Visibility */}
        <div className="col-span-2 rounded bg-surface-3 p-3">
          <div className="mb-1 flex items-center gap-1.5 text-[10px] uppercase text-muted-foreground">
            <Eye className="h-3 w-3" />
            Visibility
          </div>
          <div className="font-mono text-lg font-bold text-foreground">
            {weatherData.visibility} nm
          </div>
        </div>
      </div>
      
      {/* Passage Risk Badge */}
      <div className="mb-4 rounded-lg bg-surface-3 p-4">
        <div className="mb-2 flex items-center justify-between">
          <span className="text-[10px] font-semibold uppercase tracking-wider text-muted-foreground">
            Passage Risk
          </span>
          <div className="flex items-center gap-2">
            <div className={cn('h-3 w-3 rounded-full', risk.bg, risk.led)} />
            <span className={cn('font-mono text-sm font-bold uppercase', risk.text)}>
              {weatherData.passageRisk}
            </span>
          </div>
        </div>
        <p className="text-xs leading-relaxed text-muted-foreground">
          {weatherData.riskRationale}
        </p>
      </div>
      
      {/* 5-Day Forecast */}
      <div>
        <div className="mb-3 text-[10px] font-semibold uppercase tracking-wider text-muted-foreground">
          5-Day Outlook
        </div>
        <div className="flex justify-between">
          {weatherData.forecast.map((day) => {
            const dayRisk = riskColors[day.risk];
            return (
              <div key={day.day} className="flex flex-col items-center gap-1.5">
                <span className="text-xs font-medium text-muted-foreground">{day.day}</span>
                <div className={cn('h-3 w-3 rounded-full', dayRisk.bg, dayRisk.led)} />
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
}
