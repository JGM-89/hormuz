'use client';

import {
  AreaChart,
  Area,
  BarChart,
  Bar,
  PieChart,
  Pie,
  Cell,
  XAxis,
  YAxis,
  Tooltip,
  ResponsiveContainer,
  Legend,
} from 'recharts';
import { trafficData } from '@/lib/mock-data';

const CustomTooltip = ({
  active,
  payload,
  label,
}: {
  active?: boolean;
  payload?: Array<{ name: string; value: number; color: string }>;
  label?: string;
}) => {
  if (active && payload && payload.length) {
    return (
      <div className="rounded border border-border bg-surface-2 p-2 shadow-lg">
        <p className="mb-1 font-mono text-xs text-muted-foreground">{label}</p>
        {payload.map((entry, index) => (
          <p key={index} className="font-mono text-xs" style={{ color: entry.color }}>
            {entry.name}: {entry.value}
          </p>
        ))}
      </div>
    );
  }
  return null;
};

export function AnalyticsPanel() {
  return (
    <div className="p-4">
      <h2 className="mb-4 text-xs font-semibold uppercase tracking-wider text-muted-foreground">
        TRAFFIC ANALYTICS
      </h2>
      
      {/* Transit Counts Chart */}
      <div className="mb-6">
        <h3 className="mb-3 text-[10px] font-semibold uppercase tracking-wider text-muted-foreground">
          Hourly Transits (24h)
        </h3>
        <div className="h-32">
          <ResponsiveContainer width="100%" height="100%">
            <AreaChart
              data={trafficData.hourlyTransits.filter((_, i) => i % 3 === 0)}
              margin={{ top: 5, right: 5, left: -20, bottom: 0 }}
            >
              <defs>
                <linearGradient id="eastboundGradient" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor="#00b4d8" stopOpacity={0.3} />
                  <stop offset="95%" stopColor="#00b4d8" stopOpacity={0} />
                </linearGradient>
                <linearGradient id="westboundGradient" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor="#ffab00" stopOpacity={0.3} />
                  <stop offset="95%" stopColor="#ffab00" stopOpacity={0} />
                </linearGradient>
              </defs>
              <XAxis
                dataKey="hour"
                tick={{ fontSize: 9, fill: '#94a3b8' }}
                tickLine={false}
                axisLine={false}
              />
              <YAxis
                tick={{ fontSize: 9, fill: '#94a3b8' }}
                tickLine={false}
                axisLine={false}
              />
              <Tooltip content={<CustomTooltip />} />
              <Area
                type="monotone"
                dataKey="eastbound"
                stroke="#00b4d8"
                strokeWidth={2}
                fill="url(#eastboundGradient)"
                name="Eastbound"
              />
              <Area
                type="monotone"
                dataKey="westbound"
                stroke="#ffab00"
                strokeWidth={2}
                fill="url(#westboundGradient)"
                name="Westbound"
              />
            </AreaChart>
          </ResponsiveContainer>
        </div>
        <div className="mt-2 flex justify-center gap-4">
          <div className="flex items-center gap-1.5">
            <div className="h-2 w-2 rounded-full bg-[#00b4d8]" />
            <span className="text-[10px] text-muted-foreground">Eastbound</span>
          </div>
          <div className="flex items-center gap-1.5">
            <div className="h-2 w-2 rounded-full bg-[#ffab00]" />
            <span className="text-[10px] text-muted-foreground">Westbound</span>
          </div>
        </div>
      </div>
      
      {/* Weekly Volume Chart */}
      <div className="mb-6">
        <h3 className="mb-3 text-[10px] font-semibold uppercase tracking-wider text-muted-foreground">
          Weekly Volume
        </h3>
        <div className="h-24">
          <ResponsiveContainer width="100%" height="100%">
            <BarChart
              data={trafficData.weeklyVolume}
              margin={{ top: 5, right: 5, left: -20, bottom: 0 }}
            >
              <XAxis
                dataKey="day"
                tick={{ fontSize: 9, fill: '#94a3b8' }}
                tickLine={false}
                axisLine={false}
              />
              <YAxis
                tick={{ fontSize: 9, fill: '#94a3b8' }}
                tickLine={false}
                axisLine={false}
              />
              <Tooltip content={<CustomTooltip />} />
              <Bar dataKey="volume" fill="#00b4d8" radius={[2, 2, 0, 0]} name="Transits" />
            </BarChart>
          </ResponsiveContainer>
        </div>
      </div>
      
      {/* Fleet Composition Donut */}
      <div>
        <h3 className="mb-3 text-[10px] font-semibold uppercase tracking-wider text-muted-foreground">
          Fleet Composition
        </h3>
        <div className="flex items-center gap-4">
          <div className="h-24 w-24">
            <ResponsiveContainer width="100%" height="100%">
              <PieChart>
                <Pie
                  data={trafficData.fleetComposition}
                  cx="50%"
                  cy="50%"
                  innerRadius={25}
                  outerRadius={40}
                  paddingAngle={2}
                  dataKey="value"
                >
                  {trafficData.fleetComposition.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={entry.color} />
                  ))}
                </Pie>
              </PieChart>
            </ResponsiveContainer>
          </div>
          <div className="flex-1 space-y-2">
            {trafficData.fleetComposition.map((item) => (
              <div key={item.name} className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <div
                    className="h-2 w-2 rounded-full"
                    style={{ backgroundColor: item.color }}
                  />
                  <span className="text-xs text-muted-foreground">{item.name}</span>
                </div>
                <span className="font-mono text-xs font-semibold text-foreground">
                  {item.value}%
                </span>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}
