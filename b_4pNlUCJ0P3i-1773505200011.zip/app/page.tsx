'use client';

import { useState, useEffect } from 'react';
import {
  ResizableHandle,
  ResizablePanel,
  ResizablePanelGroup,
} from '@/components/ui/resizable';
import { VesselList } from '@/components/dashboard/vessel-list';
import { MapView } from '@/components/dashboard/map-view';
import { CommodityPanel } from '@/components/dashboard/commodity-panel';
import { WeatherPanel } from '@/components/dashboard/weather-panel';
import { AnalyticsPanel } from '@/components/dashboard/analytics-panel';
import { NewsTicker } from '@/components/dashboard/news-ticker';
import { ScrollArea } from '@/components/ui/scroll-area';
import { type Vessel } from '@/lib/mock-data';
import {
  ChevronLeft,
  ChevronRight,
  Ship,
  Activity,
  Clock,
} from 'lucide-react';
import { cn } from '@/lib/utils';

export default function HormuzCommand() {
  const [selectedVessel, setSelectedVessel] = useState<Vessel | null>(null);
  const [leftPanelCollapsed, setLeftPanelCollapsed] = useState(false);
  const [rightPanelCollapsed, setRightPanelCollapsed] = useState(false);
  const [currentTime, setCurrentTime] = useState<string | null>(null);

  useEffect(() => {
    const formatTime = () => {
      return new Date().toLocaleTimeString('en-US', {
        hour: '2-digit',
        minute: '2-digit',
        second: '2-digit',
        hour12: false,
      });
    };
    
    setCurrentTime(formatTime());
    const interval = setInterval(() => {
      setCurrentTime(formatTime());
    }, 1000);
    
    return () => clearInterval(interval);
  }, []);

  const handleSelectVessel = (vessel: Vessel | null) => {
    setSelectedVessel(vessel);
  };

  return (
    <div className="flex h-screen flex-col overflow-hidden bg-background grid-pattern">
      {/* Header */}
      <header className="flex h-14 items-center justify-between border-b border-border bg-surface-2 px-4">
        <div className="flex items-center gap-4">
          <div className="flex items-center gap-2">
            <Ship className="h-6 w-6 text-primary" />
            <h1 className="font-mono text-lg font-bold tracking-tight text-foreground">
              HORMUZ<span className="text-primary">COMMAND</span>
            </h1>
          </div>
          <div className="h-6 w-px bg-border" />
          <div className="flex items-center gap-2">
            <div className="h-2 w-2 animate-pulse rounded-full bg-[#00e676] led-green" />
            <span className="text-xs font-semibold uppercase tracking-wider text-[#00e676]">
              System Online
            </span>
          </div>
        </div>

        <div className="flex items-center gap-6">
          <div className="flex items-center gap-2 text-muted-foreground">
            <Activity className="h-4 w-4" />
            <span className="font-mono text-xs">
              12 VESSELS IN TRANSIT
            </span>
          </div>
          <div className="flex items-center gap-2 text-muted-foreground">
            <Clock className="h-4 w-4" />
            <span className="font-mono text-xs">
              {currentTime ?? '--:--:--'} UTC
            </span>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <div className="flex-1 overflow-hidden">
        <ResizablePanelGroup direction="horizontal" className="h-full">
          {/* Left Panel - Vessel List */}
          <ResizablePanel
            defaultSize={20}
            minSize={leftPanelCollapsed ? 3 : 15}
            maxSize={leftPanelCollapsed ? 3 : 30}
            collapsible
            collapsedSize={3}
            onCollapse={() => setLeftPanelCollapsed(true)}
            onExpand={() => setLeftPanelCollapsed(false)}
            className={cn(
              'relative bg-surface-1',
              leftPanelCollapsed && 'transition-all'
            )}
          >
            {leftPanelCollapsed ? (
              <button
                onClick={() => setLeftPanelCollapsed(false)}
                className="flex h-full w-full flex-col items-center justify-center gap-2 text-muted-foreground hover:text-foreground"
              >
                <ChevronRight className="h-5 w-5" />
                <span className="text-[10px] uppercase tracking-wider [writing-mode:vertical-lr]">
                  Vessels
                </span>
              </button>
            ) : (
              <VesselList
                selectedVesselId={selectedVessel?.id || null}
                onSelectVessel={handleSelectVessel}
              />
            )}
          </ResizablePanel>

          <ResizableHandle className="resize-handle w-1" />

          {/* Center - Map */}
          <ResizablePanel defaultSize={55} minSize={30}>
            <MapView
              selectedVessel={selectedVessel}
              onSelectVessel={handleSelectVessel}
            />
          </ResizablePanel>

          <ResizableHandle className="resize-handle w-1" />

          {/* Right Panel - Data Panels */}
          <ResizablePanel
            defaultSize={25}
            minSize={rightPanelCollapsed ? 3 : 20}
            maxSize={rightPanelCollapsed ? 3 : 35}
            collapsible
            collapsedSize={3}
            onCollapse={() => setRightPanelCollapsed(true)}
            onExpand={() => setRightPanelCollapsed(false)}
            className={cn(
              'relative bg-surface-1',
              rightPanelCollapsed && 'transition-all'
            )}
          >
            {rightPanelCollapsed ? (
              <button
                onClick={() => setRightPanelCollapsed(false)}
                className="flex h-full w-full flex-col items-center justify-center gap-2 text-muted-foreground hover:text-foreground"
              >
                <ChevronLeft className="h-5 w-5" />
                <span className="text-[10px] uppercase tracking-wider [writing-mode:vertical-rl] rotate-180">
                  Data Panels
                </span>
              </button>
            ) : (
              <ScrollArea className="h-full">
                <CommodityPanel />
                <WeatherPanel />
                <AnalyticsPanel />
              </ScrollArea>
            )}
          </ResizablePanel>
        </ResizablePanelGroup>
      </div>

      {/* News Ticker */}
      <NewsTicker />
    </div>
  );
}
