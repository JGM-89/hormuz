// Vessel Types
export type VesselType = 'tanker' | 'cargo' | 'other';
export type VesselStatus = 'transit' | 'anchored';

export interface Vessel {
  id: string;
  name: string;
  flag: string;
  flagEmoji: string;
  type: VesselType;
  status: VesselStatus;
  speed: number;
  heading: number;
  lat: number;
  lng: number;
  destination: string;
  cargo?: string;
  dwt?: number;
  trail: [number, number][];
}

export interface Commodity {
  id: string;
  name: string;
  symbol: string;
  price: number;
  change: number;
  changePercent: number;
  ohlc: { open: number; high: number; low: number; close: number };
  dayRange: { min: number; max: number };
  hormuzSensitivity: number;
  sparklineData: number[];
  unit: string;
}

export interface WeatherData {
  windSpeed: number;
  windDirection: number;
  windGusts: number;
  beaufortScale: number;
  beaufortLabel: string;
  waveHeight: number;
  temperature: number;
  visibility: number;
  passageRisk: 'LOW' | 'MODERATE' | 'HIGH' | 'SEVERE';
  riskRationale: string;
  forecast: { day: string; risk: 'LOW' | 'MODERATE' | 'HIGH' | 'SEVERE' }[];
}

export interface NewsItem {
  id: string;
  headline: string;
  source: string;
  timestamp: Date;
}

export interface ChokepointLocation {
  id: string;
  name: string;
  lat: number;
  lng: number;
  type: 'strait' | 'port' | 'terminal';
}

// Mock Vessels
export const vessels: Vessel[] = [
  {
    id: 'v1',
    name: 'PERSIAN GLORY',
    flag: 'Iran',
    flagEmoji: '🇮🇷',
    type: 'tanker',
    status: 'transit',
    speed: 12.4,
    heading: 135,
    lat: 26.5667,
    lng: 56.2500,
    destination: 'Fujairah',
    cargo: 'Crude Oil',
    dwt: 320000,
    trail: [[56.20, 26.60], [56.22, 26.58], [56.24, 26.57], [56.25, 26.5667]],
  },
  {
    id: 'v2',
    name: 'EMIRATES STAR',
    flag: 'UAE',
    flagEmoji: '🇦🇪',
    type: 'tanker',
    status: 'transit',
    speed: 14.2,
    heading: 315,
    lat: 26.4833,
    lng: 56.4167,
    destination: 'Ras Tanura',
    cargo: 'LNG',
    dwt: 280000,
    trail: [[56.45, 26.45], [56.43, 26.47], [56.42, 26.48], [56.4167, 26.4833]],
  },
  {
    id: 'v3',
    name: 'ARABIAN PIONEER',
    flag: 'Saudi Arabia',
    flagEmoji: '🇸🇦',
    type: 'tanker',
    status: 'anchored',
    speed: 0,
    heading: 90,
    lat: 25.2867,
    lng: 55.2800,
    destination: 'Fujairah',
    cargo: 'Crude Oil',
    dwt: 350000,
    trail: [],
  },
  {
    id: 'v4',
    name: 'GULF CARRIER',
    flag: 'Kuwait',
    flagEmoji: '🇰🇼',
    type: 'cargo',
    status: 'transit',
    speed: 11.8,
    heading: 270,
    lat: 26.7500,
    lng: 56.0833,
    destination: 'Dubai',
    dwt: 85000,
    trail: [[56.12, 26.72], [56.10, 26.74], [56.09, 26.75], [56.0833, 26.7500]],
  },
  {
    id: 'v5',
    name: 'OMAN TRADER',
    flag: 'Oman',
    flagEmoji: '🇴🇲',
    type: 'tanker',
    status: 'transit',
    speed: 13.5,
    heading: 45,
    lat: 26.3333,
    lng: 56.5833,
    destination: 'Kharg Island',
    cargo: 'Refined Products',
    dwt: 150000,
    trail: [[56.55, 26.30], [56.57, 26.31], [56.58, 26.32], [56.5833, 26.3333]],
  },
  {
    id: 'v6',
    name: 'QATAR ENERGY',
    flag: 'Qatar',
    flagEmoji: '🇶🇦',
    type: 'tanker',
    status: 'transit',
    speed: 15.1,
    heading: 180,
    lat: 26.6500,
    lng: 56.1667,
    destination: 'Fujairah',
    cargo: 'LNG',
    dwt: 290000,
    trail: [[56.17, 26.68], [56.17, 26.67], [56.17, 26.66], [56.1667, 26.6500]],
  },
  {
    id: 'v7',
    name: 'HORMUZ EXPRESS',
    flag: 'Singapore',
    flagEmoji: '🇸🇬',
    type: 'cargo',
    status: 'transit',
    speed: 10.2,
    heading: 90,
    lat: 26.4167,
    lng: 56.3333,
    destination: 'Mumbai',
    dwt: 72000,
    trail: [[56.30, 26.42], [56.31, 26.42], [56.32, 26.42], [56.3333, 26.4167]],
  },
  {
    id: 'v8',
    name: 'PACIFIC VOYAGER',
    flag: 'Japan',
    flagEmoji: '🇯🇵',
    type: 'tanker',
    status: 'transit',
    speed: 12.8,
    heading: 270,
    lat: 26.5000,
    lng: 56.5000,
    destination: 'Yokohama',
    cargo: 'Crude Oil',
    dwt: 310000,
    trail: [[56.53, 26.49], [56.52, 26.49], [56.51, 26.50], [56.5000, 26.5000]],
  },
  {
    id: 'v9',
    name: 'CHINA STRENGTH',
    flag: 'China',
    flagEmoji: '🇨🇳',
    type: 'tanker',
    status: 'anchored',
    speed: 0,
    heading: 180,
    lat: 25.3500,
    lng: 55.4000,
    destination: 'Shanghai',
    cargo: 'Crude Oil',
    dwt: 340000,
    trail: [],
  },
  {
    id: 'v10',
    name: 'BAHRAIN SPIRIT',
    flag: 'Bahrain',
    flagEmoji: '🇧🇭',
    type: 'other',
    status: 'transit',
    speed: 8.5,
    heading: 225,
    lat: 26.2833,
    lng: 56.4500,
    destination: 'Manama',
    dwt: 45000,
    trail: [[56.48, 26.26], [56.47, 26.27], [56.46, 26.28], [56.4500, 26.2833]],
  },
  {
    id: 'v11',
    name: 'INDIAN OCEAN',
    flag: 'India',
    flagEmoji: '🇮🇳',
    type: 'tanker',
    status: 'transit',
    speed: 11.2,
    heading: 315,
    lat: 26.6167,
    lng: 56.3500,
    destination: 'Mumbai',
    cargo: 'Crude Oil',
    dwt: 275000,
    trail: [[56.38, 26.59], [56.37, 26.60], [56.36, 26.61], [56.3500, 26.6167]],
  },
  {
    id: 'v12',
    name: 'KOREAN VENTURE',
    flag: 'South Korea',
    flagEmoji: '🇰🇷',
    type: 'tanker',
    status: 'transit',
    speed: 13.9,
    heading: 45,
    lat: 26.3667,
    lng: 56.2167,
    destination: 'Busan',
    cargo: 'LNG',
    dwt: 260000,
    trail: [[56.19, 26.34], [56.20, 26.35], [56.21, 26.36], [56.2167, 26.3667]],
  },
];

// Static sparkline data (deterministic to avoid hydration mismatch)
const sparklineData = {
  brent: [86.2, 86.8, 87.1, 86.5, 86.9, 87.3, 87.0, 86.7, 87.2, 87.5, 87.1, 86.8, 87.4, 87.8, 87.3, 87.0, 87.6, 87.2, 86.9, 87.4, 87.1, 87.5, 87.3, 87.42],
  wti: [82.5, 82.9, 83.2, 82.8, 83.1, 83.5, 83.2, 82.9, 83.3, 83.6, 83.2, 82.8, 83.4, 83.8, 83.3, 83.0, 83.6, 83.2, 82.9, 83.4, 83.1, 83.5, 83.3, 83.56],
  natgas: [2.91, 2.88, 2.85, 2.89, 2.86, 2.82, 2.85, 2.88, 2.84, 2.81, 2.85, 2.89, 2.83, 2.79, 2.84, 2.87, 2.81, 2.85, 2.88, 2.83, 2.86, 2.82, 2.85, 2.847],
  ttf: [33.8, 34.1, 34.4, 33.9, 34.2, 34.6, 34.3, 34.0, 34.4, 34.7, 34.3, 34.0, 34.5, 34.9, 34.4, 34.1, 34.7, 34.3, 34.0, 34.5, 34.2, 34.6, 34.4, 34.52],
  aluminum: [2405, 2398, 2390, 2402, 2395, 2385, 2392, 2400, 2388, 2380, 2390, 2398, 2382, 2375, 2388, 2395, 2378, 2390, 2398, 2382, 2392, 2385, 2390, 2387.5],
  lng: [12.5, 12.6, 12.7, 12.55, 12.65, 12.75, 12.6, 12.5, 12.7, 12.8, 12.65, 12.55, 12.75, 12.9, 12.7, 12.6, 12.8, 12.65, 12.55, 12.75, 12.6, 12.8, 12.7, 12.85],
  urea: [325, 322, 318, 324, 320, 315, 319, 323, 316, 312, 318, 324, 314, 310, 317, 322, 313, 319, 324, 315, 320, 316, 318, 315],
  ammonia: [412, 415, 418, 413, 417, 422, 418, 414, 420, 425, 419, 414, 422, 428, 420, 416, 424, 418, 414, 422, 417, 424, 420, 425.75],
};

// Mock Commodities
export const commodities: Commodity[] = [
  {
    id: 'brent',
    name: 'Brent Crude',
    symbol: 'BRN',
    price: 87.42,
    change: 1.23,
    changePercent: 1.43,
    ohlc: { open: 86.15, high: 88.20, low: 85.90, close: 87.42 },
    dayRange: { min: 85.90, max: 88.20 },
    hormuzSensitivity: 92,
    sparklineData: sparklineData.brent,
    unit: '$/bbl',
  },
  {
    id: 'wti',
    name: 'WTI Crude',
    symbol: 'WTI',
    price: 83.56,
    change: 0.89,
    changePercent: 1.08,
    ohlc: { open: 82.65, high: 84.30, low: 82.40, close: 83.56 },
    dayRange: { min: 82.40, max: 84.30 },
    hormuzSensitivity: 78,
    sparklineData: sparklineData.wti,
    unit: '$/bbl',
  },
  {
    id: 'natgas',
    name: 'Natural Gas',
    symbol: 'NG',
    price: 2.847,
    change: -0.052,
    changePercent: -1.79,
    ohlc: { open: 2.91, high: 2.95, low: 2.82, close: 2.847 },
    dayRange: { min: 2.82, max: 2.95 },
    hormuzSensitivity: 45,
    sparklineData: sparklineData.natgas,
    unit: '$/MMBtu',
  },
  {
    id: 'ttf',
    name: 'TTF Gas',
    symbol: 'TTF',
    price: 34.52,
    change: 0.67,
    changePercent: 1.98,
    ohlc: { open: 33.80, high: 35.10, low: 33.65, close: 34.52 },
    dayRange: { min: 33.65, max: 35.10 },
    hormuzSensitivity: 38,
    sparklineData: sparklineData.ttf,
    unit: '€/MWh',
  },
  {
    id: 'aluminum',
    name: 'Aluminum',
    symbol: 'ALU',
    price: 2387.50,
    change: -15.25,
    changePercent: -0.63,
    ohlc: { open: 2405, high: 2415, low: 2380, close: 2387.50 },
    dayRange: { min: 2380, max: 2415 },
    hormuzSensitivity: 22,
    sparklineData: sparklineData.aluminum,
    unit: '$/t',
  },
  {
    id: 'lng',
    name: 'LNG Spot',
    symbol: 'LNG',
    price: 12.85,
    change: 0.32,
    changePercent: 2.55,
    ohlc: { open: 12.50, high: 13.10, low: 12.45, close: 12.85 },
    dayRange: { min: 12.45, max: 13.10 },
    hormuzSensitivity: 85,
    sparklineData: sparklineData.lng,
    unit: '$/MMBtu',
  },
  {
    id: 'urea',
    name: 'Urea',
    symbol: 'URA',
    price: 315.00,
    change: -8.50,
    changePercent: -2.63,
    ohlc: { open: 325, high: 328, low: 312, close: 315 },
    dayRange: { min: 312, max: 328 },
    hormuzSensitivity: 55,
    sparklineData: sparklineData.urea,
    unit: '$/t',
  },
  {
    id: 'ammonia',
    name: 'Ammonia',
    symbol: 'NH3',
    price: 425.75,
    change: 12.25,
    changePercent: 2.96,
    ohlc: { open: 412, high: 430, low: 410, close: 425.75 },
    dayRange: { min: 410, max: 430 },
    hormuzSensitivity: 62,
    sparklineData: sparklineData.ammonia,
    unit: '$/t',
  },
];

// Mock Weather Data
export const weatherData: WeatherData = {
  windSpeed: 18,
  windDirection: 315,
  windGusts: 28,
  beaufortScale: 5,
  beaufortLabel: 'Fresh Breeze',
  waveHeight: 1.8,
  temperature: 32,
  visibility: 12,
  passageRisk: 'MODERATE',
  riskRationale: 'Elevated wind speeds and moderate wave heights may affect smaller vessels. Large tankers unaffected.',
  forecast: [
    { day: 'Mon', risk: 'MODERATE' },
    { day: 'Tue', risk: 'LOW' },
    { day: 'Wed', risk: 'LOW' },
    { day: 'Thu', risk: 'HIGH' },
    { day: 'Fri', risk: 'MODERATE' },
  ],
};

// Mock News
export const newsItems: NewsItem[] = [
  { id: 'n1', headline: 'OPEC+ agrees to extend production cuts through Q3 2026', source: 'Reuters', timestamp: new Date() },
  { id: 'n2', headline: 'Iran increases daily oil exports to 2.1M barrels amid eased sanctions', source: 'Bloomberg', timestamp: new Date() },
  { id: 'n3', headline: 'UAE announces expansion of Fujairah oil terminal capacity', source: 'Gulf News', timestamp: new Date() },
  { id: 'n4', headline: 'Saudi Aramco reports record Q1 profits, eyes LNG expansion', source: 'Financial Times', timestamp: new Date() },
  { id: 'n5', headline: 'China oil imports via Hormuz up 15% year-over-year', source: 'CNBC', timestamp: new Date() },
  { id: 'n6', headline: 'Naval exercises scheduled in Gulf of Oman next week', source: 'Jane\'s Defence', timestamp: new Date() },
  { id: 'n7', headline: 'Shipping insurance premiums for Gulf transit remain elevated', source: 'Lloyd\'s List', timestamp: new Date() },
  { id: 'n8', headline: 'Qatar Energy signs 27-year LNG supply deal with Asian buyers', source: 'Energy Intelligence', timestamp: new Date() },
];

// Chokepoint Locations
export const chokepointLocations: ChokepointLocation[] = [
  { id: 'hormuz', name: 'Strait of Hormuz', lat: 26.5667, lng: 56.2500, type: 'strait' },
  { id: 'fujairah', name: 'Fujairah', lat: 25.1167, lng: 56.3500, type: 'port' },
  { id: 'kharg', name: 'Kharg Island', lat: 29.2333, lng: 50.3167, type: 'terminal' },
  { id: 'ras-tanura', name: 'Ras Tanura', lat: 26.6400, lng: 50.1600, type: 'terminal' },
];

// Traffic Analytics Data (static to avoid hydration mismatch)
export const trafficData = {
  hourlyTransits: [
    { hour: '00:00', eastbound: 8, westbound: 6 },
    { hour: '01:00', eastbound: 6, westbound: 5 },
    { hour: '02:00', eastbound: 7, westbound: 7 },
    { hour: '03:00', eastbound: 9, westbound: 6 },
    { hour: '04:00', eastbound: 10, westbound: 8 },
    { hour: '05:00', eastbound: 11, westbound: 9 },
    { hour: '06:00', eastbound: 12, westbound: 10 },
    { hour: '07:00', eastbound: 11, westbound: 9 },
    { hour: '08:00', eastbound: 10, westbound: 8 },
    { hour: '09:00', eastbound: 9, westbound: 7 },
    { hour: '10:00', eastbound: 8, westbound: 6 },
    { hour: '11:00', eastbound: 7, westbound: 5 },
    { hour: '12:00', eastbound: 8, westbound: 6 },
    { hour: '13:00', eastbound: 9, westbound: 7 },
    { hour: '14:00', eastbound: 10, westbound: 8 },
    { hour: '15:00', eastbound: 11, westbound: 9 },
    { hour: '16:00', eastbound: 12, westbound: 10 },
    { hour: '17:00', eastbound: 11, westbound: 9 },
    { hour: '18:00', eastbound: 10, westbound: 8 },
    { hour: '19:00', eastbound: 9, westbound: 7 },
    { hour: '20:00', eastbound: 8, westbound: 6 },
    { hour: '21:00', eastbound: 7, westbound: 5 },
    { hour: '22:00', eastbound: 6, westbound: 4 },
    { hour: '23:00', eastbound: 7, westbound: 5 },
  ],
  weeklyVolume: [
    { day: 'Mon', volume: 145 },
    { day: 'Tue', volume: 158 },
    { day: 'Wed', volume: 162 },
    { day: 'Thu', volume: 148 },
    { day: 'Fri', volume: 135 },
    { day: 'Sat', volume: 142 },
    { day: 'Sun', volume: 138 },
  ],
  fleetComposition: [
    { name: 'Tankers', value: 65, color: '#00b4d8' },
    { name: 'Cargo', value: 25, color: '#ffab00' },
    { name: 'Other', value: 10, color: '#94a3b8' },
  ],
};

// Hormuz Risk Premium calculation
export const hormuzRiskPremium = {
  currentPremium: 3.42,
  percentOfBrent: 3.91,
  thirtyDayAvg: 2.87,
  trend: 'up' as const,
};
